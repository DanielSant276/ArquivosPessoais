public class Texto {

public static void main(String args[]) {
    //A classe String representa uma cadeia de caracteres Unicode imutável
    String çã = "私はブラジル人です。";

    System.out.println(çã);

}

}
