/* Todo programa em Java deve possuir uma classe e o nome no arquivo deve ser
   o nome da classe principal com extensão java */
public class Hello {

// O programa executável começa dessa forma
public static void main(String args[]) {

    System.out.println("Olá, Rural");

}

}
