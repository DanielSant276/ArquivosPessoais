#include <stdio.h>
int main(){
    float temperatura;

    printf("Qual a temperatura na sua cidade hoje?: ");
    scanf("%f",&temperatura);

    if(temperatura < 22)
        printf("Eh melhor voc� se agasalhar!\n");
    else if(temperatura >= 30)
        printf("Nao esqueca de se hidratar!");
    else
        printf("Dia agrad�vel! :)");
    printf("\n\n");

    return 0;
}
