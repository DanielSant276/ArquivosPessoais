#include <stdio.h>
#include <math.h>

#define NUM_TIMES 3
#define NUM_QUESITOS 5

void preencher_array(double lista[][NUM_QUESITOS], char nom []);
double calcular_media(double lista[]);
double calcular_desvio_padrao(double lista[], double *);

int main(void){
    double notas_dos_times[NUM_TIMES][NUM_QUESITOS];
    char   nomes [NUM_TIMES] = {'A','B','C'};
    double resultados [NUM_TIMES][2] = {{0.0, 0.0},{0.0, 0.0},{0.0, 0.0}};

    preencher_array(notas_dos_times, nomes);

    int i;
    for (i = 0; i < NUM_TIMES; ++ i){
        resultados[i][1] = calcular_desvio_padrao(notas_dos_times[i], &resultados[i][0]);
        printf("Time %c:\t Media = %.2f\t Desvio padrao = %.2f\n", nomes[i], resultados[i][0] ,resultados[i][1] );
    }

    return 0;
}

void preencher_array (double lista[][NUM_QUESITOS], char nome[]) {
    int i;
    int j;
    for (i = 0; i < NUM_TIMES; ++ i){
        printf("Ingresse as %d pontuacoes do Time %c: \n", NUM_QUESITOS,nome[i]);
        for (j = 0; j < NUM_QUESITOS; ++ j)
            scanf("%lf", &lista[i][j]);
    }
}

double calcular_desvio_padrao(double lista[], double *media){
    *media = calcular_media(lista);
    double dif_dado_media = 0.0;
    double soma_qua_das_dif = 0.0;

    int i;
    for (i = 0; i < NUM_QUESITOS; ++i){
        dif_dado_media = lista[i] - *media;
        soma_qua_das_dif += pow(dif_dado_media, 2);
    }
    return sqrt(soma_qua_das_dif / NUM_QUESITOS);
}

double calcular_media(double lista[]){
    double soma = 0;

    int i;
    for (i = 0; i < NUM_QUESITOS; ++i)
        soma += lista[i];
    return (soma / NUM_QUESITOS);
}
