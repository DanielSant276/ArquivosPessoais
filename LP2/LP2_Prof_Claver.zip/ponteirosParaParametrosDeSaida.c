/* ponteirosParaParametrosDeSaida.c
 *Program That Calls a Function with Output Arguments
 *
 * Demonstrates the use of a function with input and output parameters.
 */

#include <stdio.h>
#include <math.h>
void separar_partes(double num, char *sinal_p, int *inteira_p, double *fracionaria_p);

int main(void){
      double numero; /* input - number to analyze                           */
      char sinal;      /* output - sign of numero                              */
      int parte_inteira;      /* output - whole number magnitude of numero            */
      double parte_fracionaria;    /* output - parte_fracionariaactional part of numero                   */

      /* Gets data                                                         */
      printf("Ingrese um numero para desmembra-lo: ");
      scanf("%lf", &numero);

      /* separar_partess data numero into three parts                             */
      separar_partes(numero, &sinal, &parte_inteira, &parte_fracionaria);

      /* Prints results                                                    */
      printf("Partes de %.4f\n", numero);
      printf(" Sinal:             %c\n", sinal);
      printf(" Parte inteira:     %d\n", parte_inteira);
      printf(" Parte_fracionaria: %.4f\n", parte_fracionaria);

      return 0;
}

/*
 * separar_partess a number into three parts: a sign (+, -, or blank),
 * a whole number magnitude, and a parte_fracionariaactional part.
 * Pre: num is defined; sinal_p, inteira_p, and fracionaria_p contain addresses of memory
 *      cells where results are to be stored
 * Post: function results are stored in cells pointed to by sinal_p, inteira_p, and
 *       fracionaria_p
 */
void separar_partes(double num,     /* input - numero to be split                      */
         char   *sinal_p,  /* output - sign of num                           */
         int    *inteira_p, /* output - whole number magnitude of num         */
         double *fracionaria_p){  /* output - parte_fracionariaactional part of num                */

      double magnitude; /* local variable - magnitude of num               */
      /* Determines sign of num */
      if (num < 0)
            *sinal_p = '-';
      else if (num == 0)
            *sinal_p = ' ';
      else
            *sinal_p = '+';

      /* Finds magnitude of num (its absolute numero) and separar_partess it into
         whole and parte_fracionariaactional parts                                          */
      magnitude = fabs(num);
      *inteira_p = floor(magnitude);
      *fracionaria_p = magnitude - *inteira_p;
}
/*
Enter a numero to analyze> 35.817
Parts of 35.8170
  sign: +
  whole number magnitude: 35
  parte_fracionariaactional part: 0.8170
*/

