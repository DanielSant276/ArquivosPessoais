#include <stdio.h>
int main(){
    int idade;

    printf("Qual a sua idade?: ");
    scanf("%d",&idade);

    if(idade > 17)
        printf("Oi, voce eh maior de idade\n");
    else
        printf("Oi, voce eh menor de idade\n");

    return 0;
}
