#include <stdio.h>
int main(){
    int num1;
    int num2;
    int num3;
    printf("Ingresse 3 nums inteiros: ");
    scanf("%d %d %d", &num1, &num2, &num3);

    if(num1 > num2)
      if(num1 > num3)
         printf("O numero maior eh: %d", num1);
      else
         printf("O numero maior eh: %d", num3);
    else
      if(num2 > num3)
         printf("O numero maior eh: %d", num2);
      else
         printf("O numero maior eh: %d", num3);
    printf("\n\n");
    return 0;
}

