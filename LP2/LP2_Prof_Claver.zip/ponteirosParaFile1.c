/* ponteirosParaFile.c
 * Programa que usa ponteiros para FILE
 * Pega todos os n�meros de um arquivo de entrada e
 * escreve eles arredondados para duas casas decimais, em outro arquivo, de sa�da.
 */
#include <stdio.h>

int main(void){
      FILE *entrada_p;      // ponteiro para o arquivo de entrada
      FILE *saida_p;        // ponteiro para o arquivo de sa�da

      double item;
      int estado_da_entrada;  // valor do status retornado pela fun��o fscanf

      // Prepara��o para os arquivos de entrada e sa�da
      entrada_p = fopen("entrada.txt", "r");
      saida_p   = fopen("saida.txt", "w");

      // Recebe cada �tem, o formata, e o escreve ao arquivo de sa�da
      estado_da_entrada = fscanf(entrada_p, "%lf", &item);
      while (estado_da_entrada == 1) {
          printf("Salvando no arquivo de saida o item arredondado... \n");
          fprintf(saida_p, "%.2f\n", item);
          estado_da_entrada = fscanf(entrada_p, "%lf", &item);
      }
      printf("Fechando os arquivos...\n\n");
      // Fecha os arquivos
      fclose(entrada_p);
      fclose(saida_p);

      return (0);
}

