#include <stdio.h>
#include <math.h>

#define NUM_TIMES 3
#define NUM_QUESITOS 5

void   preencher_array        (double lista[], char)    ;
double calcular_media        (double lista[])          ;
double calcular_desvio_padrao(double lista[], double *);

int main(void){
    double timeA[NUM_QUESITOS];
    double timeB[NUM_QUESITOS];
    double timeC[NUM_QUESITOS];

    char   nomes  [NUM_TIMES] = {'A','B','C'};
    double medias [NUM_TIMES] = {0.0, 0.0, 0.0};
    double desvios[NUM_TIMES] = {0.0, 0.0, 0.0};

    preencher_array(timeA,nomes[0]);
    preencher_array(timeB,nomes[1]);
    preencher_array(timeC,nomes[2]);
    desvios[0] = calcular_desvio_padrao(timeA, &medias[0]);
    desvios[1] = calcular_desvio_padrao(timeB, &medias[1]);
    desvios[2] = calcular_desvio_padrao(timeC, &medias[2]);

    int i;
    for (i = 0; i < NUM_TIMES; ++ i)
        printf("Time %c:\t Media = %.2f\t Desvio padrao = %.2f\n", nomes[i], medias[i], desvios[i]);

    return 0;
}

void preencher_array (double lista[], char nome) {
    int i;
    printf("Ingresse as %d pontuacoes do Time %c: \n", NUM_QUESITOS,nome);
    for (i = 0; i < NUM_QUESITOS; ++ i)
        scanf("%lf", &lista[i]);
}

double calcular_desvio_padrao(double lista[], double *media){
    *media = calcular_media(lista);
    double dif_dado_media = 0.0;
    double soma_qua_das_dif = 0.0;

    int i;
    for (i = 0; i < NUM_QUESITOS; ++i){
        dif_dado_media = lista[i] - *media;
        soma_qua_das_dif += pow(dif_dado_media, 2);
    }
    return sqrt(soma_qua_das_dif / NUM_QUESITOS);
}

double calcular_media(double lista[]){
    double soma = 0;

    int i;
    for (i = 0; i < NUM_QUESITOS; ++i)
        soma += lista[i];
    return (soma / NUM_QUESITOS);
}
