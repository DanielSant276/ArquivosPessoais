#include <stdio.h>
#include <stdlib.h>

#define linhas 10
#define colunas 10

int main() {
    int linhas1, colunas1;
    int linhas2, colunas2;
    int i,j;
    float matriz1[linhas][colunas];
    float matriz2[linhas][colunas];
    float matriz_soma[linhas][colunas];
    printf("Quantas linhas tem a matriz 1? : ");
    scanf("%d", &linhas1);
    printf("Quantas colunas tem a matriz 1?: ");
    scanf("%d", &colunas1);
    printf("Preenchendo a matriz 1:\n");
    for(i = 0; i< linhas1; i++){
        for(j = 0; j<colunas1; j++){
            printf("\tIngresse o valor para o elemento %d,%d : ", i+1, j+1);
            scanf("%f", &matriz1[i][j]);
        }
    }
    printf("\n");
    printf("Quantas linhas tem a matriz 2? : ");
    scanf("%d", &linhas2);
    printf("Quantas colunas tem a matriz 2?: ");
    scanf("%d", &colunas2);
    printf("Preenchendo a matriz 2\n");
    for(i = 0; i< linhas2; i++){
        for(j = 0; j<colunas2; j++){
            printf("\tIngresse o valor para o elemento %d,%d : ", i+1, j+1);
            scanf("%f", &matriz2[i][j]);
        }
    }
    printf("\nMatriz 1:\n");
    for(i = 0; i < linhas1; i++){
        printf("\t");
        for(j = 0; j < colunas1; j++){
            printf("%.2f   ", matriz1[i][j]);
        }
        printf("\n");
    }
    printf("\nMatriz 2:\n");
    for(i = 0; i < linhas2; i++){
        printf("\t");
        for(j = 0; j < colunas2; j++)
            printf("%.2f   ", matriz2[i][j]);
        printf("\n");
    }
    if((linhas1 == linhas2) && (colunas1 == colunas2)){
        printf("\nA soma das matrices eh possivel. ");
        printf("A matriz soma eh: \n");
        for(i = 0; i<linhas1; i++)
            for(j = 0; j<colunas1; j++)
                matriz_soma[i][j] = matriz1[i][j]+matriz2[i][j];
        for( i = 0; i < linhas1; i++){
            printf("\t");
            for( j = 0; j < colunas1; j++)
                printf("%.2f   ", matriz_soma[i][j]);
            printf("\n");
        }
    }
    else
        printf("\nA soma das matrices nao eh possivel.\n\n");
    return 0;
}
