/* ponteirosParaMultiplasChamadasFuncao.c
/* Programa que ordena tr�s n�meros */

#include <stdio.h>

void ordenar(double *menor_p, double *maior_p);

int main(void)
{
        double num1, num2, num3; /* three numbers to put in order       */

        /* Gets test data                                               */
        printf("Ingresse 3 numeros separados por espaco: ");
        scanf("%lf%lf%lf", &num1, &num2, &num3);

        /* Orders the three numbers                                     */
        ordenar(&num1, &num2);
        ordenar(&num1, &num3);
        ordenar(&num2, &num3);

        /* Displays results                                             */
        printf("Os numeros em ordem ascendente sao: %.2f %.2f %.2f\n",
               num1, num2, num3);

        return 0;
}

/*
 * Ordena os argumentos de forma ascendente
 * Antes : menor_p e maior_p s�o endere�os de vari�veis tipo double
 * Depois: a vari�vel apontada por menor_p cont�m o menor dos valores de tipo double;
 *         a vari�vel apontada por maoirp cont�m o maior valor
 */
void ordenar(double *menor_p, double *maior_p)    /* entrada/sa�da */
{
        double temp; /* temporary variable to hold one number during swap      */
        /* Compares values pointed to by smp and lgp and switches if necessary */
         if (*menor_p > *maior_p) {
               temp = *menor_p;
           *menor_p = *maior_p;
           *maior_p = temp;
        }
}
/*
Enter three numbers separated by blanks> 7.5 9.6 5.5
The numbers in ascending order are: 5.50 7.50 9.60
*/

