#include <stdio.h>
int main()
{
   int a;
   char b;
   float c;
   double d;
   printf("Tamanho no armazenamento de um dado tipo int: %d Bytes \n",sizeof(a));
   printf("Tamanho no armazenamento de um dado tipo char: %d Bytes \n",sizeof(b));
   printf("Tamanho no armazenamento de um dado tipo float: %d Bytes \n",sizeof(c));
   printf("Tamanho no armazenamento de um dado tipo double: %d Bytes \n",sizeof(d));
   return 0;
}
