#include <stdio.h>
#include <math.h>

#define NUM_ITEMS 3

int main(void){
    double x[NUM_ITEMS];
    double soma;
    double media;
    double dif_dado_media;
    double soma_qua_das_dif;
    double desvio_padrao;

    int    i;

    printf("Ingresse %d numeros separados por espaco ou <enter>s\n> ", NUM_ITEMS);
    for (i = 0; i < NUM_ITEMS; ++ i)
        scanf("%lf", &x [i]);

    soma = 0;
    for (i = 0; i < NUM_ITEMS; ++i)
        soma += x[i];
    media = soma / NUM_ITEMS;

    soma_qua_das_dif = 0;
    for (i = 0; i < NUM_ITEMS; ++i){
        dif_dado_media = x[i] - media;
        soma_qua_das_dif += pow(dif_dado_media, 2);
    }
    desvio_padrao = sqrt(soma_qua_das_dif / NUM_ITEMS);

    printf("A media eh %.2f.\n", media);
    printf("O desvio padrao eh %.2f.\n", desvio_padrao);

    printf("\nTabela de diferencas entre os dados e a media\n");
    printf("Indice      Dado        Diferenca\n");
    for (i = 0; i < NUM_ITEMS;  ++i)
        printf("%3d%4c%9.2f%5c%9.2f\n", i, ' ', x[i], ' ', x[i] - media);

    return 0;
}
