#include <stdio.h>
int main(){
    int contador;
    for(contador=0;contador<100;contador=contador+1)
        printf("Nunca mais vou falar palavrao dentro da sala de aula\n");

    return 0;
}
