#include <stdio.h>
#define LITROS_POR_GALAO 3.7854

int main(void){

    double galoes;
    double litros;

    printf("Ingresse o numero de galoes: ");
    scanf("%lf", &galoes);

    litros = LITROS_POR_GALAO * galoes;
    printf("%lf galoes equivalem a %f litros.\n", galoes, litros);
    return 0;
}
